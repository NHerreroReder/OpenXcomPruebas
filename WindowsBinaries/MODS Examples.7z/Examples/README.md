# XCom Files Garage mod
This mod is an example to test the operation of the HangarsReworked
OXCE+ fork. It has been designed as a submod of the magnificent
mod "The Xcom Files", but it should be easily reworked for another 
master mod or the vanilla game.

Garage mod provides a new 1x1 facility addressed to store cars, vans,
and similar crafts. To do so, it is assigned a "hangarType" value of 
0, in its rule definition (see facilities_garage_XCF.rul). Similarly, 
the same value is given to the four types of vehicle-like crafts in
"The Xcom Files" (see crafts_garage_XCF.rul). 
A Basescape sprite and a mapblock have been build to represent the new 
facility in-game. Its UEFOPAEDIA entry is also included.

Finally a slightly modified starting base has been also included, so
you initially begin with just 2 garages, instead of two hangars.

# XFCMultiHangar-MOD Example
This other mod adds another one to the garage facility; a 3x3 Hangar 
with capacity for 4 crafts. Some crafts has been adapted so they can
be stored in the facility (see .rul files in Ruleset folder). This mod
uses elements from 0xJEBC's Facility Pack.

